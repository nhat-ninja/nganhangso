package vn.funix.fx19041.java.asm04;

public class Asm04 {

}
