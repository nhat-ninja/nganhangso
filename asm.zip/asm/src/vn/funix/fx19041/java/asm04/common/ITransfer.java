package vn.funix.fx19041.java.asm04.common;

public interface ITransfer {

}

