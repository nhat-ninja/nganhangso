package vn.funix.fx19041.java.asm03.models;

public interface ReportService {
    void log(double amount);
}
